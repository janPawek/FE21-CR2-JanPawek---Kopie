const JSONobj = `[{

        "taskName": "Take a dog for a walk",

        "image": "https://picsum.photos/id/237/200/150",

        "description": "take a tour around a playground right to the dog park. Let him play for 20 mins with other dogs. Dont forget to bring a threats",

        "importance": 0,
        "deadline": "11.02.2023",
        "done": false

    },
    {

        "taskName": "Take out the garbage",

        "image": "https://picsum.photos/id/231/200/150",

        "description": "see if there is any recycling in the garbage. If there is, separate it. also check house for any other food leftovers or trash.",

        "importance": 0,
        "deadline": "12.02.2023",
        "done": false

    },
    {

        "taskName": "Go to the grocery store",

        "image": "https://picsum.photos/id/232/200/150",

        "description": "go to the grocery store and buy some food. Make sure to buy some fruits and vegetables. Also buy some milk and eggs.",

        "importance": 0,
        "deadline": "13.02.2023",
        "done": false

    },
    {

        "taskName": "hang out with friends",

        "image": "https://picsum.photos/id/233/200/150",

        "description": "dont forget to call crew as planed at 6pm. Also, dont forget to bring a gift for Annie. Its her birthday today",

        "importance": 0,
        "deadline": "14.02.2023",
        "done": false

    },
    {

        "taskName": "prepare dinner for tomorrow",

        "image": "https://picsum.photos/id/234/200/150",

        "description": "prepare dinner for tomorrow. Make sure to buy all the ingredients today, becouse tomorrow is a busy day",

        "importance": 0,
        "deadline": "15.02.2023",
        "done": false

    },
    {

        "taskName": "take some rest",

        "image": "https://picsum.photos/id/235/200/150",

        "description": "take some rest. You have been working hard for the last few days. You deserve a break",

        "importance": 0,
        "deadline": "16.02.2023",
        "done": false

    },{

        "taskName": "remember to eat healthy",

        "image": "https://picsum.photos/id/242/200/150",

        "description": "it will really help you to stay healthy and fit. Also, it will help you to stay focused on your tasks",

        "importance": 0,
        "deadline": "17.02.2023",
        "done": false

    },{

        "taskName": "apply for Job",

        "image": "https://picsum.photos/id/241/200/150",

        "description": "apply for a job. You have been looking for a job for a while now. You need to start applying for jobs",

        "importance": 0,
        "deadline": "13.02.2023",
        "done": false

    },{

        "taskName": "learn new skills",

        "image": "https://picsum.photos/id/240/200/150",

        "description": "new skills will help you to get a better job. You need to start learning!",

        "importance": 0,
        "deadline": "18.02.2023",
        "done": false

    }]`